<?php 

$con = new mysqli('localhost' , 'root', '', 'form_data');


if($con->connect_error){
    die("connection failed:" . $conn-> connect_error);

}

$name = $_POST['name'];
$email = $_POST['email'];


$sql = "INSERT INTO users (name , email) VALUES ('$name', '$email')";

if($con->query($sql) === TRUE){
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $con->error;
}   

$con->close();
?>