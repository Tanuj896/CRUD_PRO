<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

    <title>uni4x</title>

    <!-- Fav Icon -->
    <link rel="icon" href="web_assets/images/favicon.ico" type="image/x-icon">

    <!-- Google Fonts -->
    <link
        href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap"
        rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;1,100;1,200;1,300;1,400;1,500;1,600;1,700&display=swap"
        rel="stylesheet">

    <!-- Stylesheets -->
    <link href="web_assets/css/font-awesome-all.css" rel="stylesheet">
    <link href="web_assets/css/flaticon.css" rel="stylesheet">
    <link href="web_assets/css/owl.css" rel="stylesheet">
    <link href="web_assets/css/bootstrap.css" rel="stylesheet">
    <link href="web_assets/css/jquery.fancybox.min.css" rel="stylesheet">
    <link href="web_assets/css/animate.css" rel="stylesheet">
    <link href="web_assets/css/nice-select.css" rel="stylesheet">
    <link href="web_assets/css/odometer.css" rel="stylesheet">
    <link href="web_assets/css/elpath.css" rel="stylesheet">
    <link href="web_assets/css/color.css" id="jssDefault" rel="stylesheet">
    <link href="web_assets/css/rtl.css" rel="stylesheet">
    <link href="web_assets/css/style.css" rel="stylesheet">
    <link href="web_assets/css/module-css/header.css" rel="stylesheet">
    <link href="web_assets/css/module-css/banner.css" rel="stylesheet">
    <link href="web_assets/css/module-css/clients.css" rel="stylesheet">
    <link href="web_assets/css/module-css/account.css" rel="stylesheet">
    <link href="web_assets/css/module-css/about.css" rel="stylesheet">
    <link href="web_assets/css/module-css/funfact.css" rel="stylesheet">
    <link href="web_assets/css/module-css/trading.css" rel="stylesheet">
    <link href="web_assets/css/module-css/process.css" rel="stylesheet">
    <link href="web_assets/css/module-css/award.css" rel="stylesheet">
    <link href="web_assets/css/module-css/apps.css" rel="stylesheet">
    <link href="web_assets/css/module-css/news.css" rel="stylesheet">
    <link href="web_assets/css/module-css/subscribe.css" rel="stylesheet">
    <link href="web_assets/css/module-css/footer.css" rel="stylesheet">
    <link href="web_assets/css/responsive.css" rel="stylesheet">

</head>


<!-- page wrapper -->

<body>

    <div class="boxed_wrapper ltr">


        <!-- preloader -->

        <!-- preloader end -->


        <!-- page-direction -->
        <div class="page_direction">
            <div class="demo-rtl direction_switch"><button class="rtl">RTL</button></div>
            <div class="demo-ltr direction_switch"><button class="ltr">LTR</button></div>
        </div>
        <!-- page-direction end -->


        <!--Search Popup-->
        <div id="search-popup" class="search-popup">
            <div class="popup-inner">
                <div class="upper-box">
                    <figure class="logo-box p_relative z_1"><a href="#"><img src="web_assets/images/logoess.webp"
                                alt=""></a></figure>
                    <div class="close-search"><i class="fal fa-times"></i></div>
                </div>
                <div class="overlay-layer"></div>
                <div class="auto-container">
                    <div class="search-form">
                        <form method="post" action="#">
                            <div class="form-group">
                                <fieldset>
                                    <input type="search" class="form-control" name="search-input" value=""
                                        placeholder="Type your keyword and hit" required>
                                    <button type="submit"><i class="icon-10"></i></button>
                                </fieldset>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>


        <!-- main header -->
        <header class="main-header header-style-one">
            <!-- header-top -->
            <div class="header-top">
                <div class="large-container">
                    <div class="top-inner">
                        <div class="support-box">
                            <div class="icon-box"><i class="icon-07"></i></div>
                            <a href="tel:912345678">91 xxxxxxx</a>
                        </div>
                        <div class="option-block">
                            <div class="language-picker js-language-picker mr_40" data-trigger-class="btn btn--subtle">
                                <form action="#" class="language-picker__form">
                                    <label for="language-picker-select">Select your language</label>
                                    <select name="language-picker-select" id="language-picker-select">
                                        <option lang="de" value="deutsch"></option>
                                        <option lang="en" value="english" selected></option>
                                        <option lang="fr" value="francais"></option>
                                        <option lang="it" value="italiano"></option>
                                    </select>
                                </form>
                            </div>
                            <a href="#" class="theme-btn btn-one mr_10">Open Account</a>
                            <a href="#" class="theme-btn btn-two">Login</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- header-lower -->
            <div class="header-lower">
                <div class="large-container">
                    <div class="outer-box">
                        <figure class="logo-box"><a href="#"><img style="width: 180px;"
                                    src="web_assets/images/logoess.webp " alt=""></a>
                        </figure>
                        <div class="menu-area">
                            <!--Mobile Navigation Toggler-->
                            <div class="mobile-nav-toggler">
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                            </div>
                            <nav class="main-menu navbar-expand-md navbar-light clearfix">
                                <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                    <ul class="navigation clearfix">
                                        <li class="current dropdown"><a href="#">Home</a>

                                        </li>
                                        <li class="dropdown"><a href="#">Trading</a>

                                        </li>
                                        <li class="dropdown"><a href="#">Market</a>

                                        </li>
                                        <li class="dropdown"><a href="#">About Us</a>

                                        </li>
                                        <li class="dropdown"><a href="#">Blog</a>

                                        </li>
                                        <li><a href="#">Contact</a></li>
                                    </ul>
                                </div>
                            </nav>
                            <div class="search-btn ml_30"><button class="search-toggler"><i
                                        class="icon-10"></i></button></div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- header-bottom -->
            <div class="header-bottom">
                <div class="large-container">
                    <div class="bottom-inner">
                        <div class="inner-box">
                            <ul class="stock-list">
                                <li class="upper">US30 394833.90 <span>(+0.93 <i class="icon-06"></i>)</span></li>
                                <li class="lower">US30 391323.90 <span>(-0.12 <i class="icon-05"></i>)</span></li>
                                <li class="lower">US30 391467.90 <span>(-0.35 <i class="icon-05"></i>)</span></li>
                                <li class="upper">US30 354033.90 <span>(+0.55 <i class="icon-06"></i>)</span></li>
                                <li class="upper">US30 394346.90 <span>(+0.76 <i class="icon-06"></i>)</span></li>
                                <li class="lower">US30 391300.90 <span>(-0.43 <i class="icon-05"></i>)</span></li>
                                <li class="upper">US30 394833.90 <span>(+0.93 <i class="icon-06"></i>)</span></li>
                                <li class="lower">US30 391323.90 <span>(-0.12 <i class="icon-05"></i>)</span></li>
                                <li class="lower">US30 391467.90 <span>(-0.35 <i class="icon-05"></i>)</span></li>
                                <li class="upper">US30 354033.90 <span>(+0.55 <i class="icon-06"></i>)</span></li>
                                <li class="upper">US30 394346.90 <span>(+0.76 <i class="icon-06"></i>)</span></li>
                                <li class="lower">US30 391300.90 <span>(-0.43 <i class="icon-05"></i>)</span></li>
                                <li class="upper">US30 394833.90 <span>(+0.93 <i class="icon-06"></i>)</span></li>
                                <li class="lower">US30 391323.90 <span>(-0.12 <i class="icon-05"></i>)</span></li>
                                <li class="lower">US30 391467.90 <span>(-0.35 <i class="icon-05"></i>)</span></li>
                                <li class="upper">US30 354033.90 <span>(+0.55 <i class="icon-06"></i>)</span></li>
                                <li class="upper">US30 394346.90 <span>(+0.76 <i class="icon-06"></i>)</span></li>
                                <li class="lower">US30 391300.90 <span>(-0.43 <i class="icon-05"></i>)</span></li>
                                <li class="upper">US30 394833.90 <span>(+0.93 <i class="icon-06"></i>)</span></li>
                                <li class="lower">US30 391323.90 <span>(-0.12 <i class="icon-05"></i>)</span></li>
                                <li class="lower">US30 391467.90 <span>(-0.35 <i class="icon-05"></i>)</span></li>
                                <li class="upper">US30 354033.90 <span>(+0.55 <i class="icon-06"></i>)</span></li>
                                <li class="upper">US30 394346.90 <span>(+0.76 <i class="icon-06"></i>)</span></li>
                                <li class="lower">US30 391300.90 <span>(-0.43 <i class="icon-05"></i>)</span></li>
                                <li class="upper">US30 394833.90 <span>(+0.93 <i class="icon-06"></i>)</span></li>
                                <li class="lower">US30 391323.90 <span>(-0.12 <i class="icon-05"></i>)</span></li>
                                <li class="lower">US30 391467.90 <span>(-0.35 <i class="icon-05"></i>)</span></li>
                                <li class="upper">US30 354033.90 <span>(+0.55 <i class="icon-06"></i>)</span></li>
                                <li class="upper">US30 394346.90 <span>(+0.76 <i class="icon-06"></i>)</span></li>
                                <li class="lower">US30 391300.90 <span>(-0.43 <i class="icon-05"></i>)</span></li>
                                <li class="upper">US30 394833.90 <span>(+0.93 <i class="icon-06"></i>)</span></li>
                                <li class="lower">US30 391323.90 <span>(-0.12 <i class="icon-05"></i>)</span></li>
                                <li class="lower">US30 391467.90 <span>(-0.35 <i class="icon-05"></i>)</span></li>
                                <li class="upper">US30 354033.90 <span>(+0.55 <i class="icon-06"></i>)</span></li>
                                <li class="upper">US30 394346.90 <span>(+0.76 <i class="icon-06"></i>)</span></li>
                                <li class="lower">US30 391300.90 <span>(-0.43 <i class="icon-05"></i>)</span></li>
                                <li class="upper">US30 394833.90 <span>(+0.93 <i class="icon-06"></i>)</span></li>
                                <li class="lower">US30 391323.90 <span>(-0.12 <i class="icon-05"></i>)</span></li>
                                <li class="lower">US30 391467.90 <span>(-0.35 <i class="icon-05"></i>)</span></li>
                                <li class="upper">US30 354033.90 <span>(+0.55 <i class="icon-06"></i>)</span></li>
                                <li class="upper">US30 394346.90 <span>(+0.76 <i class="icon-06"></i>)</span></li>
                                <li class="lower">US30 391300.90 <span>(-0.43 <i class="icon-05"></i>)</span></li>
                                <li class="upper">US30 394833.90 <span>(+0.93 <i class="icon-06"></i>)</span></li>
                                <li class="lower">US30 391323.90 <span>(-0.12 <i class="icon-05"></i>)</span></li>
                                <li class="lower">US30 391467.90 <span>(-0.35 <i class="icon-05"></i>)</span></li>
                                <li class="upper">US30 354033.90 <span>(+0.55 <i class="icon-06"></i>)</span></li>
                                <li class="upper">US30 394346.90 <span>(+0.76 <i class="icon-06"></i>)</span></li>
                                <li class="lower">US30 391300.90 <span>(-0.43 <i class="icon-05"></i>)</span></li>
                                <li class="upper">US30 394833.90 <span>(+0.93 <i class="icon-06"></i>)</span></li>
                                <li class="lower">US30 391323.90 <span>(-0.12 <i class="icon-05"></i>)</span></li>
                                <li class="lower">US30 391467.90 <span>(-0.35 <i class="icon-05"></i>)</span></li>
                                <li class="upper">US30 354033.90 <span>(+0.55 <i class="icon-06"></i>)</span></li>
                                <li class="upper">US30 394346.90 <span>(+0.76 <i class="icon-06"></i>)</span></li>
                                <li class="lower">US30 391300.90 <span>(-0.43 <i class="icon-05"></i>)</span></li>
                                <li class="upper">US30 394833.90 <span>(+0.93 <i class="icon-06"></i>)</span></li>
                                <li class="lower">US30 391323.90 <span>(-0.12 <i class="icon-05"></i>)</span></li>
                                <li class="lower">US30 391467.90 <span>(-0.35 <i class="icon-05"></i>)</span></li>
                                <li class="upper">US30 354033.90 <span>(+0.55 <i class="icon-06"></i>)</span></li>
                                <li class="upper">US30 394346.90 <span>(+0.76 <i class="icon-06"></i>)</span></li>
                                <li class="lower">US30 391300.90 <span>(-0.43 <i class="icon-05"></i>)</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!--sticky Header-->
            <div class="sticky-header">
                <div class="large-container">
                    <div class="outer-box">
                        <figure class="logo-box"><a href="#"><img style="width: 180px;"
                                    src="web_assets/images/logoess.webp" alt=""></a>
                        </figure>
                        <div class="menu-area">
                            <nav class="main-menu clearfix">
                                <!--Keep This Empty / Menu will come through Javascript-->
                            </nav>
                            <div class="search-btn ml_30"><button class="search-toggler"><i
                                        class="icon-10"></i></button></div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- main-header end -->


        <!-- Mobile Menu  -->
        <div class="mobile-menu">
            <div class="menu-backdrop"></div>
            <div class="close-btn"><i class="fas fa-times"></i></div>
            <nav class="menu-box">
                <div class="nav-logo"><a href="#"><img src="web_assets/images/logoess.webp" alt="" title=""></a>
                </div>
                <div class="menu-outer">
                    <!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header-->
                </div>
                <div class="contact-info">
                    <h4>Contact Info</h4>
                    <ul>
                        <li>Chicago 12, Melborne City, USA</li>
                        <li><a href="tel:+8801682648101">+88 01682648101</a></li>
                        <li><a href="mailto:info@example.com">info@example.com</a></li>
                    </ul>
                </div>
                <div class="social-links">
                    <ul class="clearfix">
                        <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                        <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                        <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
                        <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                        <li><a href="#"><span class="fab fa-youtube"></span></a></li>
                    </ul>
                </div>
            </nav>
        </div>
        <!-- End Mobile Menu -->
