<?php

$host = "localhost";
$user = "root";
$pass = "";
$db = "DUMMY";

$con = mysqli_connect($host, $user, $pass, $db);

if ($con) {
    echo " ";
} else {
    echo "Connection Failed: ";
}
    // echo "Connection Successful";    