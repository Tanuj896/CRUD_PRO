<?php include 'connection.php';
$Rollno = $_GET['id'];
$select = "SELECT * FROM CSE WHERE Rollno='$Rollno'";
$data = mysqli_query($con, $select);
$result = mysqli_fetch_array($data);
?>
<style>
    /* Page and Body Style */
    body {
        margin: 0;
        padding: 0;
        background-color: #000;
        font-family: 'Segoe UI', sans-serif;
        color: #fff;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }

    /* Form container */
    form {
        background-color: #111;
        padding: 40px 30px;
        border-radius: 10px;
        box-shadow: 0 0 15px rgba(255, 255, 255, 0.1);
        width: 320px;
    }

    /* Input fields */
    form input[type="text"],
    form input[type="number"],
    form input[type="email"],
    form input[type="mail"],
    form input[type="submit"] {
        width: 100%;
        padding: 10px;
        margin: 10px 0;
        border: 1px solid #fff;
        background-color: #000;
        color: #fff;
        border-radius: 6px;
        font-size: 15px;
        transition: all 0.3s ease;
    }

    /* Input focus */
    form input:focus {
        outline: none;
        border-color: #fff;
        background-color: #1a1a1a;
    }

    /* Submit button */
    form input[type="submit"] {
        background-color: #fff;
        color: #000;
        font-weight: bold;
        cursor: pointer;
        border: none;
    }

    form input[type="submit"]:hover {
        background-color: #ccc;
    }

    /* Back button styling */
    form button {
        width: 100%;
        padding: 10px;
        background-color: #fff;
        border: none;
        border-radius: 6px;
        margin-top: 10px;
        cursor: pointer;
        transition: 0.3s;
    }

    form button a {
        text-decoration: none;
        color: #000;
        font-weight: bold;
        display: block;
    }

    form button:hover {
        background-color: #ccc;
    }
</style>
<div>
    <form action="" method="POST">
        <input value="<?php echo $result['Rollno'] ?>" type="number" name="Rollno" placeholder="Enter Roll No" required /><br><br>

        <input value="<?php echo $result['Firstname'] ?>" type="text" name="Firstname" placeholder="Enter First Name " required /><br><br>

        <input value="<?php echo $result['lastname'] ?>" type="text" name="lastname" placeholder="Enter Last Name " required /><br><br>

        <input value="<?php echo $result['age'] ?>" type="number" name="age" placeholder="Enter age " required /><br><br>

        <input value="<?php echo $result['Mail'] ?>" type="mail" name="Mail" placeholder="Enter Mail id " required /><br><br>

        <input value="<?php echo $result['subject'] ?>" type="text" name="subject" placeholder="Enter Query " required /><br><br>

        <input type="submit" name="update_btn" value="update" /><br><br>

        <button><a href="view.php">Back Table </a></button>
    </form>
</div>

<?php
if (isset($_POST['update_btn'])) {
    $rollno = $_POST['Rollno'];
    $firstname = $_POST['Firstname'];
    $lastname = $_POST['lastname'];
    $age = $_POST['age'];
    $mail = $_POST['Mail'];
    $subject = $_POST['subject'];

    $update = "UPDATE  CSE SET Rollno='$rollno', Firstname='$firstname', lastname='$lastname', age='$age', Mail='$mail', subject='$subject' WHERE Rollno='$Rollno'";
    $data = mysqli_query($con, $update);
    if ($data) {

        echo "Data update Successfully";
    } else {
        echo "Sorry no update : " . mysqli_error($con);
    }
}
?>