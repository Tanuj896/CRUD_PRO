<?php include('connection.php'); ?>

<style>
    body {
        font-family: 'Segoe UI', sans-serif;
        background-color: #000;
        color: #fff;
        padding: 30px;
    }

    /* Table styling */
    table {
        width: 100%;
        border-collapse: collapse;
        background-color: #111;
        color: #fff;
        margin-top: 20px;
        border: 1px solid #fff;
    }

    th,
    td {
        border: 1px solid #fff;
        padding: 10px 15px;
        text-align: center;
    }

    th {
        background-color: #222;
        font-weight: bold;
        text-transform: uppercase;
    }

    tr:nth-child(even) {
        background-color: #1a1a1a;
    }

    /* Links inside action buttons */
    a {
        color: #00f0ff;
        text-decoration: none;
        font-weight: bold;
    }

    a:hover {
        color: #fff;
        text-decoration: underline;
    }

    /* Button styling */
    button {
        margin-top: 20px;
        padding: 10px 20px;
        background-color: #fff;
        color: #000;
        font-size: 16px;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    button a {
        color: #000;
        text-decoration: none;
        font-weight: bold;
    }

    button:hover {
        background-color: #ccc;
    }
</style>

<table border="2px solid black cellpadding=" 10px" cellspacing="0" width="100%">
    <tr></tr>
    <th>Roll No</th>
    <th>First Name</th>
    <th>Last Name</th>
    <th>Age</th>
    <th>Mail ID</th>
    <th>Subject</th>
    <th>Action</th>
    </tr>
    <?php
    $query = "SELECT * FROM CSE";
    $data = mysqli_query($con, $query);
    $total = mysqli_num_rows($data);
    if ($total) {
        while ($result = mysqli_fetch_array($data)) {
    ?>
            <tr>
                <td> <?php echo  $result['Rollno']; ?></td>
                <td> <?php echo  $result['Firstname']; ?></td>
                <td> <?php echo  $result['lastname']; ?></td>
                <td> <?php echo  $result['age']; ?></td>
                <td> <?php echo  $result['Mail']; ?></td>
                <td> <?php echo  $result['subject']; ?></td>
                <td> <a href="update.php?id=<?php echo  $result['Rollno']; ?>">EDIT </a> </td>
                <td> <a onclick="return conform('are you sure conform to  delete')" href="Delete.php?id=<?php echo  $result['Rollno']; ?>">Delete </a> </td>


            </tr>

    <?php

        }
    }
    ?>


</table>

<button> <a href="index.php"> Form here </a> </button>