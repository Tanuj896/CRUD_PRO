<?php include('connection.php'); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form </title>
    <link rel="stylesheet" href="style.css">
</head>
<style></style>

<body>
    <DIV>

        <h1 style="padding-right: 140px; font-size: 40px;"> Student Form</h1>
        <p>Fill in the details below:</p>
    </DIV>
    <div>

        <form action="" method="POST">
            <input type="number" name="Rollno" placeholder="Enter Roll No" required /><br><br>

            <input type="text" name="Firstname" placeholder="Enter First Name " required /><br><br>

            <input type="text" name="lastname" placeholder="Enter Last Name " required /><br><br>

            <input type="number" name="age" placeholder="Enter age " required /><br><br>

            <input type="mail" name="Mail" placeholder="Enter Mail id " required /><br><br>

            <input type="text" name="subject" placeholder="Enter Query " required /><br><br>

            <input type="submit" name="save_btn" value="Save" /><br><br>

            <button><a href="view.php">View Table </a></button>
        </form>
    </div>
    <?php
    if (isset($_POST['save_btn'])) {
        $rollno = $_POST['Rollno'];
        $firstname = $_POST['Firstname'];
        $lastname = $_POST['lastname'];
        $age = $_POST['age'];
        $mail = $_POST['Mail'];
        $subject = $_POST['subject'];

        $query = "INSERT INTO `CSE`(`Rollno`, `Firstname`, `lastname`, `age`, `Mail`, `subject`) VALUES ('$rollno', '$firstname', '$lastname', '$age', '$mail', '$subject')";
        $data = mysqli_query($con, $query);
        if ($data) {
            echo "Data Inserted Successfully";
        } else {
            echo "Failed to Insert Data: " . mysqli_error($con);
        }
    }
    ?>

</html>