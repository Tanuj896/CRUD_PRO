<?php include 'connection.php';
$Rollno = $_GET['id'];
$query = "DELETE FROM CSE WHERE Rollno='$Rollno'";
$data =  mysqli_query($con, $query);

if ($data) {
    echo "<script>
    alert('Data Deleted Successfully');
    window.open('view.php', '_self');
    
    </script>";
    header("Location: view.php");
} else {
    echo "Failed to Delete Data: " . mysqli_error($con);
}
